



(function (global) {
  "use strict";
  var lwapi;
  var allSubComps = [];
  var highlightedFromTree;
  var checkedFromTree;


  var LwInteropApi = function (modelPath, needToIsolate, modelToIsolate) {
    allSubComps = [];

    console.log(modelPath, needToIsolate, modelToIsolate);
    var modelToOpen = modelPath, isolate = needToIsolate || false;
    var isolatedModel ='';

    if( needToIsolate ){
      isolatedModel = modelToIsolate;
    }
    console.log( modelToOpen, isolate, isolatedModel);
    var myframe = document.getElementById('threedframe');

    if (myframe) {
      var win = myframe.contentWindow || myframe;
      //document.getElementById('lw-canvas').style.background='black'
      lwapi = new LwApiPM(win);
      

      lwapi.applyConfig({
        showNavbar: false,
        treeExpanded: false,
        navbarEntries: {
          fitAllIn: true,
          fitInItem: true,
          shaded: false
        },
        showBottomToolbar: false
      })
        .then(lwapi.registerOnSelection.bind(lwapi, function (selectedItem) {
          
          if ( /*(highlightedFromTree === undefined || !highlightedFromTree)
           && */selectedItem !== undefined && selectedItem !== null) {
            if (selectedItem.item !== undefined && selectedItem.item !== null) {
              
              window.dispatchEvent(new CustomEvent('threed-selection-event',
                { 'detail': {'modelId':selectedItem.item.modelId + ':' + selectedItem.item.modelItemId , 'fromTree':highlightedFromTree}}));
            }
          }
          highlightedFromTree = false;
       
        }))
        .then(lwapi.registerOnReady.bind(lwapi, (function () {
          
          if (isolate && allSubComps[0] !== undefined) {
           
            window.dispatchEvent(new CustomEvent('threed-isolate-comp-event', { 'detail': allSubComps[0] }));
            lwapi.isolate(allSubComps[0]);
            lwapi.reframe(allSubComps[0]);
          }
          window.dispatchEvent(new CustomEvent('threed-loaded-event'));
        })))
        .then(
          lwapi.registerOnVisibility.bind(lwapi, (function (selectedItem) {
            console.log('*** VISIBLE:', selectedItem);
          })))
    }

    this.loadModel = function () {

      if (lwapi) {
        lwapi.openModel(modelPath).then(
          lwapi.getTree(modelToOpen).then(tree => {
            if (isolate && isolatedModel !== '') {
              this.getMatchingChild(tree.root, isolatedModel);
            }
          })
        ).catch(function (error) {
          alert(error);
          console.error('LwApi Error:', error);
        });
      }
    }

    this.highlightComp = function (modelIds, highlight, fromTree) {
      highlightedFromTree = fromTree;
      modelIds.forEach(modelId => {
        lwapi.setNodeSelection(modelId, highlight);
      })
    }

    this.showOrHideComp = function (modelIds, showOrHide, fromTree) {
      
      checkedFromTree = fromTree;
      modelIds.forEach(modelId => {
        lwapi.setNodeVisibility(modelId, showOrHide);
      })
    }

    this.getMatchingChild = function (foundTreeItem, compName) {

      var subComps = foundTreeItem.children;
      for (var indx = 0; indx < subComps.length; indx++) {
        
        if ( subComps[indx].children ) {
          if (subComps[indx].text === compName) {
            subComps[indx].children.forEach( child => {
              if( child.type !== undefined && child.type !== null && child.type === "part"){
                allSubComps.unshift( child.id);
              }else{
                allSubComps.push(subComps[indx].id);
              }
            })
          }else{
            this.getMatchingChild(subComps[indx], compName);
          }
        }
        else {
          if (subComps[indx].text === compName) {
            allSubComps.push(subComps[indx].id);
          }
        }
      }
    };

    this.fitAllInView = function () {
      lwapi.reframe("");
    }

    this.setView = function (viewNumber) {
      lwapi.setView(viewNumber);
    }

    this.togglePmiVisibility = function (toggle) {
      lwapi.setPmiVisibility(toggle);
    }


  };



  if (("function" === typeof define) && (define["amd"])) /* AMD Support */ {
    define(function () {
      return LwInteropApi;
    });
  } else if ("undefined" !== typeof exports) /* Node Support */ {
    if (("undefined" !== typeof module) && module["exports"]) {
      module["exports"] = LwInteropApi;
      exports = LwInteropApi;
    }
    else {
      exports = LwInteropApi;
    }
  } else { /* Browsers and Web Workers*/
    global["LwInteropApi"] = LwInteropApi;
  }
}(this));