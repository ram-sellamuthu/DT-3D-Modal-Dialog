import { Injectable, NgZone } from '@angular/core';
import { ViewerMessageService } from './viewer-message.service';

declare var LwInteropApi : any;

@Injectable({
  providedIn: 'root'
})
export class LwInteropService {
  
  

  jsObj : any;
  constructor( private msgService : ViewerMessageService, private zone: NgZone) { 
    
  }

  loadThreeDModel( toIsolate : boolean, modelToIsolate:string): void{
    this.msgService.show("Loading the model into scene");
    this.jsObj = new LwInteropApi("C:\\Apps\\LiteWeb\\model\\Wheel Loader.jt", toIsolate, modelToIsolate);    
    this.jsObj.loadModel();
  }

  showOrHideComp(modelIds: string[], blShow: boolean, fromTree : boolean) {
    
    this.jsObj.showOrHideComp( modelIds, blShow, fromTree );
  }

  highlightComponent( modelIds: string[], blHighlight: boolean, fromTree : boolean) {
    this.jsObj.highlightComp( modelIds , blHighlight, fromTree);
  }

  fitAll(): any {
    this.jsObj.fitAllInView();
  }

  setView(viewId : number){
    this.jsObj.setView( viewId );
  }

  togglePmiVisibility( toggle : boolean){
    this.jsObj.togglePmiVisibility( toggle );
  }
}
