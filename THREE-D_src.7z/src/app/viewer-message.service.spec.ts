import { TestBed } from '@angular/core/testing';

import { ViewerMessageService } from "./viewer-message.service";

describe('ViewerMessageService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ViewerMessageService = TestBed.get(ViewerMessageService);
    expect(service).toBeTruthy();
  });
});
 