import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreeDCommandsComponent } from './three-d-commands.component';

describe('ThreeDCommandsComponent', () => {
  let component: ThreeDCommandsComponent;
  let fixture: ComponentFixture<ThreeDCommandsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreeDCommandsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreeDCommandsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
