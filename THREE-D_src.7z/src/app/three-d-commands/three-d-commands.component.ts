import { Component, OnInit } from '@angular/core';
import { LwInteropService } from '../lw-interop.service';

@Component({
  selector: 'app-three-d-commands',
  templateUrl: './three-d-commands.component.html',
  styleUrls: ['./three-d-commands.component.css']
})
export class ThreeDCommandsComponent implements OnInit {
  private pmiVisibility : boolean = false;
  constructor( private lwService : LwInteropService ) { }

  ngOnInit() {
  }

  private fitAll(): void {
    this.lwService.fitAll();
  }

  private setView(viewId : number): void{
    this.lwService.setView( viewId );
  }

  private togglePmiVisibility( toggle : boolean): void{
    this.lwService.togglePmiVisibility( toggle );
  }

}
