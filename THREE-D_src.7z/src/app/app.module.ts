import { NgModule }       from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { FormsModule }    from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';

//import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';

import { AppRoutingModule }     from './app-routing.module';

import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import { TreeviewModule } from 'ngx-treeview';
import {NgbModule, NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

      
import { AppComponent }         from './app.component';
import { ViewerMessagesComponent }    from './viewer-messages/viewer-messages.component';
import { ThreeDFrameComponent } from './threed-frame/three-d-frame.component';
import { ThreeDTreeFrameComponent } from './three-d-tree-frame/three-d-tree-frame.component';
import { ThreeDViewerDialogComponent } from './three-d-viewer-dialog/three-d-viewer-dialog.component';
import { InMemoryThreeDDataService } from './in-memory-three-d-data.service';
import { ThreeDCommandsComponent } from './three-d-commands/three-d-commands.component';
import { ThreeDAssetDetailsComponent } from './three-d-asset-details/three-d-asset-details.component';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,    
    NoopAnimationsModule,    
    NgbModule.forRoot(),
    TreeviewModule.forRoot(),
    

    // The HttpClientInMemoryWebApiModule module intercepts HTTP requests
    // and returns simulated server responses.
    // Remove it when a real server is ready to receive requests.
    // HttpClientInMemoryWebApiModule.forRoot(
    //   InMemoryThreeDDataService,
    //    { dataEncapsulation: false }
    // )
  ],
  declarations: [
    AppComponent,
    ViewerMessagesComponent,
    ThreeDFrameComponent,
    ThreeDTreeFrameComponent,
    ThreeDViewerDialogComponent,
    ThreeDCommandsComponent,
    ThreeDAssetDetailsComponent,     
    
  ],
  providers: [
    NgbActiveModal
  ],
  entryComponents: [ThreeDViewerDialogComponent],
  bootstrap: [ AppComponent ]
})
export class AppModule { }