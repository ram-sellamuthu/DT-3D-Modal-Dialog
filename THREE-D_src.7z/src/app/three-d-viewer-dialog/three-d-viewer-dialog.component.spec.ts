import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreeDViewerDialogComponent } from './three-d-viewer-dialog.component';

describe('ThreeDViewerDialogComponent', () => {
  let component: ThreeDViewerDialogComponent;
  let fixture: ComponentFixture<ThreeDViewerDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreeDViewerDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreeDViewerDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
