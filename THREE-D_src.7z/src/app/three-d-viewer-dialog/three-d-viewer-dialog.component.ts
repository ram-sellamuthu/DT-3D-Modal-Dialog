import { Component, OnInit, Inject, ViewEncapsulation, Input, HostListener, ViewChild, ElementRef } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { ViewerMessageService } from "../viewer-message.service";
import { LwInteropService } from '../lw-interop.service';

@Component({
  selector: 'app-three-d-viewer-dialog',
  templateUrl: './three-d-viewer-dialog.component.html',
  styleUrls: ['./three-d-viewer-dialog.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ThreeDViewerDialogComponent implements OnInit{
 

  closeResult: string;
  compName : string;
  sensorInfo : string[];
  public isCollapsed = false;

  @Input() isolate:boolean = false; 
  @Input() modelToIsolate : string = "";
  @Input() title : string = "3D View";

  constructor(private modalService: NgbModal, private lwService : LwInteropService,
    private messageService: ViewerMessageService) {

    }

  ngOnInit(): void {
    this.messageService.show("Loading...");
    
  }
  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title', backdrop:"static", size: 'lg' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  @HostListener('window:threed-loaded-event', ['$event'])
  updateStatus(event) {
    this.messageService.show("Ready");
  }



}