import { Component, OnInit } from '@angular/core';
import { ViewerMessageService } from "../viewer-message.service";

@Component({
  selector: 'app-messages',
  templateUrl: './viewer-messages.component.html',
  styleUrls: ['./viewer-messages.component.css']
})
export class ViewerMessagesComponent implements OnInit {

  constructor(public messageService: ViewerMessageService) { }

  ngOnInit() {
  }

}