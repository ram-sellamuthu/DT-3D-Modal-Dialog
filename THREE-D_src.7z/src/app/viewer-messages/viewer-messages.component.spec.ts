import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewerMessagesComponent } from './viewer-messages.component';

describe('MessagesComponent', () => {
  let component: ViewerMessagesComponent;
  let fixture: ComponentFixture<ViewerMessagesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewerMessagesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewerMessagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
