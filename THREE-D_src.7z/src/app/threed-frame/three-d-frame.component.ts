import { Component, OnInit, Input } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { ViewerMessageService } from "../viewer-message.service";
import { LwInteropService } from '../lw-interop.service';

declare var LwInteropApi : any;

@Component({
  selector: 'app-three-d-frame',
  templateUrl: './three-d-frame.component.html',
  styleUrls: ['./three-d-frame.component.css']
})
export class ThreeDFrameComponent implements OnInit {

  @Input() isolate:boolean = false; 
  @Input() modelToIsolate : string ="";
  
  jsObj: any;
  dangerousUrl: string;
  trustedUrl: SafeUrl;
  constructor(private sanitizer: DomSanitizer, private msgService: ViewerMessageService, private lwService : LwInteropService) {
    this.dangerousUrl  = "http://localhost:9000"; //?model=D:\\Install_Kits\\TTC\\LiteWeb_2101\\model\\Wheel Loader.jt
    //this.dangerousUrl  = "http://proxy.transcat-plm.com:8080?model=model\\Wheel Loader.jt";
    this.trustedUrl = sanitizer.bypassSecurityTrustResourceUrl(this.dangerousUrl);
    this.jsObj = lwService;
  }

  ngOnInit() {
    this.msgService.show("Connecting with LiteWeb Application Server");
  }

  loadThreeDModel( event): void{ 

    if( event.target.src === '')
      return;
    
    if(!this.isolate){
      this.lwService.loadThreeDModel(this.isolate,"");
    }      
    else{
      this.lwService.loadThreeDModel(this.isolate,this.modelToIsolate);
    }
    

  }

}

