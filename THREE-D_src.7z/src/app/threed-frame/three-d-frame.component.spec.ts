import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreeDFrameComponent } from './three-d-frame.component';

describe('ThreedFrameComponent', () => {
  let component: ThreeDFrameComponent;
  let fixture: ComponentFixture<ThreeDFrameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreeDFrameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreeDFrameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
