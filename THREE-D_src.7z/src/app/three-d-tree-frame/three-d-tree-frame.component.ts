
import { Component, OnInit, HostListener } from '@angular/core';


import { InMemoryThreeDDataService, ThreeDTreeviewItem } from '../in-memory-three-d-data.service';
import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { LwInteropService } from '../lw-interop.service';
import { ViewerMessageService } from '../viewer-message.service';


@Component({
  selector: 'app-three-d-tree-frame',
  templateUrl: './three-d-tree-frame.component.html',
  styleUrls: ['./three-d-tree-frame.component.css'],
  providers: [InMemoryThreeDDataService]
})
export class ThreeDTreeFrameComponent implements OnInit {
  jsObj: any;
  loading = false;
  highlightedComps: ThreeDTreeviewItem[] = [];

  dropdownEnabled = true;
  items: ThreeDTreeviewItem[];
  values: number[];
  config = TreeviewConfig.create({
    hasAllCheckBox: false,
    hasFilter: true,
    hasCollapseExpand: false,
    decoupleChildFromParent: false,
    maxHeight: 500,

  });
  highlightedFromTree: boolean;
  checkedFromTree: boolean;


  constructor(private msgService: ViewerMessageService,
    private lwService: LwInteropService,
    private dataService: InMemoryThreeDDataService) {
    this.loading = true;
    this.jsObj = lwService;
    
  }

  ngAfterViewInit() {
    this.loading = false;
  }

  ngOnInit() {

    this.dataService.dataChange.subscribe(treeItems => this.items = treeItems);
    (<TreeviewItem>this.items[0]).setCheckedRecursive(true);

  }

  showOrHideComp(comp: ThreeDTreeviewItem) {
    if (!this.loading) {
      this.checkedFromTree = true;
      this.lwService.showOrHideComp(comp.value.modelIds, comp.checked, true);
    }
  }

  clearHighlights() {
    
    this.highlightedComps.forEach(currComp => {      
      currComp.selectedStyle = "";
    })
    this.highlightedComps = [];
  }

  @HostListener('window:threed-isolate-comp-event', ['$event'])
  isolateComponent(event) {
    
    (<TreeviewItem>this.items[0]).setCheckedRecursive(false);
    var compsToCheck = this.dataService.searchThreeDItem(event.detail);
    
    if (compsToCheck !== undefined){
      compsToCheck.setCheckedRecursive(true);
    }
      
  }

  @HostListener('window:threed-selection-event', ['$event'])
  syncHighlight(event) {

    if (event.detail.modelId === "1:1") {
      return;
    }
    if(event.detail.fromTree === true){
      return;
    }
    var temp = this.dataService.searchThreeDItem(event.detail.modelId);
    this.highlightComponent(temp, false);
    
  }

  highlightComponent(comp: ThreeDTreeviewItem, fromTree : boolean) {
    if (!this.loading) {
      var blHighlight = false;
      var selectedStyle: string;
      if (comp.selectedStyle === undefined || comp.selectedStyle === '') {
        selectedStyle = 'selected';
        blHighlight = true;
      } else {
        selectedStyle = '';
        blHighlight = false;
      }

      
      this.clearHighlights();
      this.setSelectionRecursively( comp, selectedStyle );

      if( fromTree ){
        var allLevelChildren: string[] = [];

        comp.value.modelIds.forEach( modelId => {
          allLevelChildren.push( modelId );
        });
        this.lwService.highlightComponent( allLevelChildren, blHighlight, true );
      }


    }
  }

  setSelectionRecursively(comp: ThreeDTreeviewItem, selectedStyle: string) {
    
    if (comp.children) {
      comp.children.forEach( child => {
        (<ThreeDTreeviewItem>child).selectedStyle = selectedStyle;
        this.highlightedComps.push( <ThreeDTreeviewItem>child );
        if (child.children) {
          this.setSelectionRecursively( <ThreeDTreeviewItem>child, selectedStyle );
        }
      });
    }

    comp.selectedStyle = selectedStyle;
    this.highlightedComps.push(comp);

    
  }

  onFilterChange(value: any) {

  }

  onSelectedChange(value: string) {

  }

}
