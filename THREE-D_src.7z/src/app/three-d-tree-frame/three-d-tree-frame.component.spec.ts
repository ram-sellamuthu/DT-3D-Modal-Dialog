import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreeDTreeFrameComponent } from './three-d-tree-frame.component';

describe('ThreedTreeFrameComponent', () => {
  let component: ThreeDTreeFrameComponent;
  let fixture: ComponentFixture<ThreeDTreeFrameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreeDTreeFrameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreeDTreeFrameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
