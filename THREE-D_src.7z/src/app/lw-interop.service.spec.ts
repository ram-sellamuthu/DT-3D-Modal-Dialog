import { TestBed } from '@angular/core/testing';

import { LwInteropService } from './lw-interop.service';

describe('LwInteropService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LwInteropService = TestBed.get(LwInteropService);
    expect(service).toBeTruthy();
  });
});
