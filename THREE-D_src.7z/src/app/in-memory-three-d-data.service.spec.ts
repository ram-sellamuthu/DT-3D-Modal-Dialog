import { TestBed } from '@angular/core/testing';

import { InMemoryThreeDDataService } from './in-memory-three-d-data.service';

describe('InMemoryThreeDDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InMemoryThreeDDataService = TestBed.get(InMemoryThreeDDataService);
    expect(service).toBeTruthy();
  });
});
