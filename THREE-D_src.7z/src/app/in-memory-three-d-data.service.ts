import { Injectable } from '@angular/core';
import {BehaviorSubject} from 'rxjs';
import { TreeviewItem } from 'ngx-treeview';

export class ThreeDModelProps {

  constructor(private modelIds: string[], private lifeChars : string[]) {

  }
  public getLifeChars() : string[]{
    return this.lifeChars;
  }
}

export class ThreeDTreeviewItem extends TreeviewItem{
  selectedStyle = "";
}

/**
 * The Json object for ThreeD list data.
 */

const rootCategory = new ThreeDTreeviewItem({
  text:"Wheel Loader", value: new ThreeDModelProps(["1:1"], []), collapsed: false, children: [
      { text: "Boom Cylinder", value: new ThreeDModelProps( [ "1:79"], []) },
      { text: "Boom Cylinder", value: new ThreeDModelProps( [ "1:2624"], []) },
      { text: "Boom Rod",  value: new ThreeDModelProps([ "1:1728" ], [])},
      { text: "Boom Rod",  value: new ThreeDModelProps([ "1:2254"], [])},
      { text: "Booms",  value: new ThreeDModelProps(["1:2094"], [])},
      { text: "Bucket",  value: new ThreeDModelProps([ "1:2780"], ["Remaining Number of Excavations: 1000"])},
      { text: "Connecting Rod",  value: new ThreeDModelProps([ "1:1470"], [])},
      { text: "Connecting Rod",  value: new ThreeDModelProps(["1:1890"], [])},
      { text: "Differential",  value: new ThreeDModelProps([ "1:127"], [])},
      { text: "Front Body", value: new ThreeDModelProps( ["1:269"], [])},
      { text: "Rear Body",  value: new ThreeDModelProps(["1:886", "1:901", "1:963", "1:1339", "1:1275", "1:1182", "1:1213", "1:1306", "1:1119", "1:994", "1:1025", "1:1056", "1:1088", "1:1370", "1:1150", "1:1244", "1:932"], [])},
      { text: "Rocker Arm", value: new ThreeDModelProps( ["1:1626" ], [])},
      { text: "Rocker Arm", value: new ThreeDModelProps( [  "1:2470"], [])},                
      { text: "Rocker Arm Cylinder", value: new ThreeDModelProps( [ "1:1992" ], ["Oil Replacement Due in: 3 months"])},
      { text: "Rocker Arm Cylinder", value: new ThreeDModelProps( [   "1:2200" ], ["Oil Replacement Due in: 3 months"])},
      { text: "Rocker Arm Rod", value: new ThreeDModelProps([  "1:221"], [])},
      { text: "Rocker Arm Rod", value: new ThreeDModelProps([  "1:2416"], [])},
      { text: "Screw_12", value: new ThreeDModelProps([ "1:2572"], [])},
      { text: "Screw_24", value: new ThreeDModelProps( [ "1:317"], [])},
      { text: "Screw_7",  value: new ThreeDModelProps(["1:16", "1:31","1:1503", "1:1524","1:1557", "1:1578","1:1815", "1:1836","1:1923", "1:1944","1:2025", "1:2046","1:2125", "1:2146","1:2341", "1:2362","1:2503", "1:2524","1:2657", "1:2678","1:2711", "1:2732","1:2865", "1:2886"], [])},
      { text: "Screw_9",  value: new ThreeDModelProps(["1:158", "1:173","1:1401", "1:1422","1:1659", "1:1680","1:1761", "1:1782","1:2287", "1:2308","1:2811", "1:2832"], [])},
      { text: "Wheels Assembly", value: new ThreeDModelProps([ "1:348" ], []) , collapsed: false, children: [
        { text: "Axle",  value: new ThreeDModelProps(["1:377"], [])},
        { text: "Rim", value: new ThreeDModelProps( [  "1:425"], [])},
        { text: "Tyre", value: new ThreeDModelProps( [  "1:527"], ["Pressure: 6 psi", "Tyre EOL: 6 Months"])},
        { text: "Rim", value: new ThreeDModelProps( [  "1:479"], [])},
        { text: "Tyre", value: new ThreeDModelProps( [  "1:581"], ["Pressure: 6 psi","Tyre EOL: 12 Months"])},
        ]
      },
      { text: "Wheels Assembly", value: new ThreeDModelProps([ "1:614"], []) , collapsed: false, children: [
          { text: "Axle",  value: new ThreeDModelProps([ "1:649"], ["End of Life: 1 year"])},
          { text: "Rim", value: new ThreeDModelProps( [   "1:697" ], [])},
          { text: "Tyre", value: new ThreeDModelProps( [   "1:799"], ["Pressure: 5 psi"])},
          { text: "Rim", value: new ThreeDModelProps( [  "1:751"], [])},
          { text: "Tyre", value: new ThreeDModelProps( [  "1:853"], ["Pressure: 5 psi"])},
          ]
        }
  ]
});


/**
 * Temporary database, it can build a tree structured Json object.
 * Each node in Json object represents a ThreeD item or a category.
 * If a node is a category, it has children items and new items can be added under the category.
 */
@Injectable({ providedIn: 'root' })
export class InMemoryThreeDDataService {
  dataChange = new BehaviorSubject<ThreeDTreeviewItem[]>([]);

  get data(): ThreeDTreeviewItem[] { return this.dataChange.value; }

  constructor() {
    this.dataChange.next(null);
    
    this.initialize();
    
  }

  initialize() {
    
    const data = [rootCategory];
    // Notify the change.
    this.dataChange.next(data);
  }

  searchThreeDItem(modelIdToMatch : string) : ThreeDTreeviewItem{
    
    var matchingItems : ThreeDTreeviewItem[];
    
    matchingItems = this.getMatchingRecursively(this.data[0], modelIdToMatch);
    
    return matchingItems[0];
  }
  
  getMatchingRecursively(comp: ThreeDTreeviewItem, modelIdToMatch: string) : ThreeDTreeviewItem[] {
    var matchingItems : ThreeDTreeviewItem[] = [];
    comp.children.forEach(child => {
      child.value.modelIds.forEach(modelId => {
          if (modelId === modelIdToMatch) {
            matchingItems.push( <ThreeDTreeviewItem>child );
          }
      });

      if (child.children) {
        var tempMatches = this.getMatchingRecursively(<ThreeDTreeviewItem>child, modelIdToMatch);
        tempMatches.forEach( temp => {
          matchingItems.push( <ThreeDTreeviewItem>temp );
        })
        
      }
    });
    
    return matchingItems;
  }

 
}

