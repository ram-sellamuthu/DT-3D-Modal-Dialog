import { Injectable } from '@angular/core';
 
@Injectable({
  providedIn: 'root',
})
export class ViewerMessageService {
  messages: string[] = [];
 
  add(message: string) {
    this.messages.push(message);
  }

  show(message: string){
    this.clear();
    this.add(message);
  }
 
  clear() {
    this.messages = [];
  }
}