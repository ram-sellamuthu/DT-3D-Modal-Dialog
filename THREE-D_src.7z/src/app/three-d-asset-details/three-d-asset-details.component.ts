import { Component, OnInit, Input, HostListener } from '@angular/core';
import { InMemoryThreeDDataService, ThreeDModelProps, ThreeDTreeviewItem } from '../in-memory-three-d-data.service';

@Component({
  selector: 'app-three-d-asset-details',
  templateUrl: './three-d-asset-details.component.html',
  styleUrls: ['./three-d-asset-details.component.css']
})
export class ThreeDAssetDetailsComponent implements OnInit {

  private compName : string;
  private sensorPropArray : SensorInfo[] = [];
  private prevSelection : ThreeDTreeviewItem;
  sameAsPrev: boolean;
  constructor(private dataService : InMemoryThreeDDataService) { }

  ngOnInit() {
  }

  @HostListener('window:threed-selection-event', ['$event'])
  syncAssetSensorData( event ) {

    this.sensorPropArray = [];
    var matchComp = this.dataService.searchThreeDItem(event.detail.modelId);
    
    if( this.prevSelection === matchComp ){
      this.sameAsPrev = true;
    }else{
      this.sameAsPrev = false;
    }
    
    this.compName = matchComp.text;
    var sensorInfo = (<ThreeDModelProps>matchComp.value).getLifeChars();

    sensorInfo.forEach( info =>{
      var indx = info.lastIndexOf(':');
      this.sensorPropArray.push(new SensorInfo(info.substring(0,indx), info.substring(indx+1)));
    })

    let element: HTMLElement = document.getElementById('iotProps') as HTMLElement;
    element.click();
    this.prevSelection = matchComp;
  }

  showLifeChars( popover ) {
    if (popover.isOpen() && this.sameAsPrev) {
      popover.close();      
    } else {
      popover.open();
    }
    
  }

}

class SensorInfo{
  constructor(private propName : string, private propValue : string){

  }
}
