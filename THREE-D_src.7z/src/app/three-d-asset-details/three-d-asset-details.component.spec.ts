import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreeDAssetDetailsComponent } from './three-d-asset-details.component';

describe('ThreeDAssetDetailsComponent', () => {
  let component: ThreeDAssetDetailsComponent;
  let fixture: ComponentFixture<ThreeDAssetDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThreeDAssetDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThreeDAssetDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
